import { createContext, useState } from 'react';
import { Cart } from '../Types/Data';

export const UserContext = createContext<{ cart?: any; setCart?: any }>({});

export const UserStorage = ({ children }: { children: React.ReactNode }) => {
  const [cart, setCart] = useState<Cart[]>([]);

  return (
    <UserContext.Provider value={{ cart, setCart }}>
      {children}
    </UserContext.Provider>
  );
};
