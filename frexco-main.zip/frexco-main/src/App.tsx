import './Styles/Default.css';
import Routes from './Routes/PublicRoutes';
import { UserStorage } from './Context/UserStorage';

function App() {
  return (
    <>
      <UserStorage>
        <Routes />
      </UserStorage>
    </>
  );
}

export default App;
