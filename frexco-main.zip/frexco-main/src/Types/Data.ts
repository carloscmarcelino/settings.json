export type Data = {
  family: string;
  genus: string;
  id: number;
  image: {
    src: string;
    alt: string;
  };
  name: string;
  nutritions: {
    calories: number;
    carbohydrates: number;
    fat: number;
    protein: number;
    sugar: number;
  };
  order: string;
  preco: string;
};

export type Cart = {
  amount: number;
  family: string;
  genus: string;
  id: number;
  image: {
    src: string;
    alt: string;
  };
  name: string;
  nutritions: {
    calories: number;
    carbohydrates: number;
    fat: number;
    protein: number;
    sugar: number;
  };
  order: string;
  preco: string;
};
