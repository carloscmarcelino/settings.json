export const fontWeight: { regular: number; bold: number } = {
  regular: 400,
  bold: 600,
};

export const fontSize: {
  sm: string;
  md: string;
  lg: string;
} = {
  sm: '1rem',
  md: '1.25rem',
  lg: '1.5rem',
};

export const lineHeight: { sm: string; md: string; lg: string } = {
  sm: 1 * 1.5 + 'rem',
  md: 1.25 * 1.5 + 'rem',
  lg: 1.5 * 1.5 + 'rem',
};

export const colors: {
  orange: string;
  purle1: string;
  purle2: string;
  white: string;
} = {
  orange: '#e80',
  purle1: '#87f',
  purle2: '#76f',
  white: '#fff',
};
