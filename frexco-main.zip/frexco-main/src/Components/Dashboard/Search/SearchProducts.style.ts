import styled from 'styled-components';
import { fontWeight, fontSize, colors } from '../../../Styles/Styles';

export const Search = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  margin-top: 50px;
  margin-bottom: 40px;
`;

export const Title = styled.h1`
  font-size: ${fontSize.md};
  font-weight: ${fontWeight.bold};
  color: ${colors.purle1};
  margin-bottom: 10px;
`;

export const Form = styled.form`
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 8px rgba(30, 60, 90, 0.1);
  @media only screen and (max-width: 500px) {
    width: 95%;
  }
`;

export const Input = styled.input`
  border: none;
  background-color: #fff;
  width: 300px;
  height: 50px;
  padding: 15px;
  border-radius: 8px 0px 0px 8px;
  &:hover {
    border: 1px solid ${colors.purle1};
  }
  @media only screen and (max-width: 500px) {
    width: 80%;
  }
`;

export const Button = styled.button`
  border: none;
  height: 50px;
  width: 50px;
  background-color: #fff;
  border-radius: 0 8px 8px 0;
  &:hover {
    border: 1px solid ${colors.purle1};
  }
  @media only screen and (max-width: 500px) {
    width: 20%;
  }
`;
