import SearchSvg from '../../../Images/SearchSvg';
import { Search } from './SearchProducts.style';
import { Title, Form, Input, Button } from './SearchProducts.style';

type SearchOptions = {
  handleSearch: any;
  value: any;
  setValue: any;
};

export const SearchProducts = ({
  handleSearch,
  value,
  setValue,
}: SearchOptions) => {
  return (
    <Search>
      <Title>Produtos</Title>
      <Form onSubmit={handleSearch}>
        <Input
          placeholder="Buscar..."
          value={value}
          onChange={({ target }) => setValue(target.value)}
        />
        <Button>
          <SearchSvg fill="currentColor" width={20} height={20} />
        </Button>
      </Form>
    </Search>
  );
};
