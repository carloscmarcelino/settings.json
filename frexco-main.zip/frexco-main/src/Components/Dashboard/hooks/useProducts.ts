import { useState, useEffect } from 'react';
import { getProducts } from '../api/getProducts';
import { Data } from '../../../Types/Data';

export const useProducts = () => {
  const [data, setData] = useState<[Data]>();

  const getData = async () => {
    const data = await getProducts();
    setData(data.data);
  };

  useEffect(() => {
    getData();
  }, []);

  return { data };
};
