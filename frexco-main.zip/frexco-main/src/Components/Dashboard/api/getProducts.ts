import axios, { AxiosResponse } from 'axios';
import { API_URL } from '../../../Api';

export const getProducts = (): Promise<AxiosResponse> => {
  return axios.get(API_URL);
};
