import { useState, useEffect } from 'react';
import { Loading } from '../Loading';
import { DashboardStyle } from './Dashboard.style';
import { useProducts } from './hooks';
import { Header } from '../Header/Header';
import { Footer } from '../Footer';
import { Title } from '../Title';
import { SearchProducts } from './Search';
import { DashboardItem } from './DashboardItem';
import React from 'react';

export const Dashboard = () => {
  const { data } = useProducts();

  const [value, setValue] = useState<string>('');
  const [result, setResult] = useState(null);

  const handleSearch = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const search: any = data?.find((item) => {
      return (
        item.name.toLowerCase() === value.toLowerCase() ||
        item.name.toUpperCase() === value.toUpperCase()
      );
    });
    setResult(search);
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Title title="Home" />
      <Header />
      <SearchProducts
        handleSearch={handleSearch}
        value={value}
        setValue={setValue}
      />
      <DashboardStyle>
        {!data && <Loading />}
        {result ? (
          <DashboardItem item={result} />
        ) : (
          data?.map((item) => (
            <React.Fragment key={item.id}>
              <DashboardItem item={item} />
            </React.Fragment>
          ))
        )}
      </DashboardStyle>
      <Footer />
    </>
  );
};
