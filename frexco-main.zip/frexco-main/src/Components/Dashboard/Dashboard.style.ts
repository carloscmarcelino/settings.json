import styled from 'styled-components';

export const DashboardStyle = styled.div`
  min-height: 62vh;
  display: flex;
  flex-direction: row;
  align-items: flex-start;
  justify-content: center;
  flex-wrap: wrap;
  max-width: 95vw;
  margin: 0 auto;
`;
