import { ItemBox, Image, Value, Name, Button } from './DashboardItem.style';
import { useNavigate } from 'react-router-dom';
import { Data } from '../../../Types/Data';

export const DashboardItem = ({ item }: { item: Data }) => {
  const navigate = useNavigate();

  return (
    <ItemBox>
      <Image src={item?.image?.src} alt={item?.image?.alt} />
      <Value>{item.preco}</Value>
      <Name>{item.name}</Name>
      <Button
        onClick={() => {
          navigate(`/product/${item.name}`);
        }}
      >
        Informações nutricionais
      </Button>
    </ItemBox>
  );
};
