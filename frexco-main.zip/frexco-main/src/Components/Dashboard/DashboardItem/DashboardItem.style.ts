import styled from 'styled-components';
import { colors, fontSize, fontWeight } from '../../../Styles/Styles';

export const ItemBox = styled.div`
  margin: 20px;
  padding: 10px;
  border-radius: 5px;
  background-color: ${colors.white};
  box-shadow: 0 6px 12px rgba(30, 60, 90, 0.2);
  transition: 0.2s;
  animation: enter 0.3s;
  @keyframes enter {
    from {
      opacity: 0;
      transform: translate3d(0, -20px, 0);
    }
    to {
      opacity: initial;
      transform: initial;
    }
  }
  &:hover {
    transform: scale(1.1);
  }
  @media only screen and (max-width: 500px) {
    width: 100%;
    margin: 20px 5px;
    &:hover {
      transform: none;
    }
  }
`;

export const Image = styled.img`
  height: 544px;
  width: 380px;
  border-radius: 8px;
  @media only screen and (max-width: 500px) {
    width: 100%;
  }
`;

export const Value = styled.h2`
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.md};
`;

export const Name = styled.h1`
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.lg};
  color: ${colors.orange};
  margin: 10px 0;
`;

export const Button = styled.button`
  background-color: ${colors.purle1};
  transition: 0.2s;
  border-radius: 8px;
  border: none;
  padding: 10px 20px;
  color: ${colors.white};
  font-weight: ${fontWeight.regular};
  font-size: ${fontSize.md};
  &:hover {
    background-color: ${colors.purle2};
    cursor: pointer;
  }
`;
