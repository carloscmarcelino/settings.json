import { LoadingStyle, Span } from './Loading.style';

export const Loading = () => {
  return (
    <LoadingStyle>
      <Span></Span>
      <Span></Span>
      <Span></Span>
      <Span></Span>
    </LoadingStyle>
  );
};
