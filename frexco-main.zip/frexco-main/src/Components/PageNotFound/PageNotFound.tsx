import { PageNotFoundStyle } from './PageNotFound.style';
import { useNavigate } from 'react-router-dom';
import { Header } from '../Header';
import { Footer } from '../Footer';

export const PageNotFound = () => {
  const navigate = useNavigate();
  return (
    <>
      <Header />
      <PageNotFoundStyle
        onClick={() => {
          navigate('/');
        }}
      >
        Page not found, click here to return to home.
      </PageNotFoundStyle>
      <Footer />
    </>
  );
};
