import { useEffect } from 'react';

type TitleType = {
  title?: string;
};

export const Title = ({ title }: TitleType) => {
  useEffect(() => {
    document.title = 'Frexco | ' + title;
  }, [title]);

  return <></>;
};
