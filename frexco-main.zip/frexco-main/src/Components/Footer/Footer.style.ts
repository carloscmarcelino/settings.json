import styled from 'styled-components';
import { colors, fontWeight, fontSize } from '../../Styles/Styles';

export const FooterStyle = styled.footer`
  min-height: 10vh;
  background-color: ${colors.purle1};
  color: ${colors.white};
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.sm};
  display: flex;
  align-items: center;
  justify-content: center;
`;
