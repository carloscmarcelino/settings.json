import { FooterStyle } from './Footer.style';

export const Footer = () => {
  return <FooterStyle>Frexco. todos os diretos reservados.</FooterStyle>;
};
