import { useContext, useEffect } from 'react';
import { Header } from '../Header';
import { Footer } from '../Footer';
import {
  EmptyCart,
  EmptyMessage,
  CartStyle,
  CartContainer,
  CartTitle,
  CartList,
  CartListItem,
  CartFinish,
  FinishTitle,
  FinishList,
  FinishListItem,
} from './Cart.style';
import { Title } from '../Title';
import { UserContext } from '../../Context/UserStorage';
import { Cart as CartOptions } from '../../Types/Data';
import TrashSvg from '../../Images/TrashSvg';

import { Data } from '../../Types/Data';

export const Cart = () => {
  const { cart, setCart } = useContext(UserContext);

  const decrement = (item: CartOptions): void => {
    const hasDuplicate = cart.find((i: Data) => i.id === item.id);
    if (hasDuplicate) {
      setCart(
        cart.map((i: Data) =>
          i.id === item.id
            ? { ...hasDuplicate, amount: hasDuplicate.amount - 1 }
            : i,
        ),
      );
    } else {
      setCart([...cart, { ...item, amount: 1 }]);
    }
  };

  const increment = (item: CartOptions): void => {
    const hasDuplicate = cart.find((i: Data) => i.id === item.id);
    if (hasDuplicate) {
      setCart(
        cart.map((i: Data) =>
          i.id === item.id
            ? { ...hasDuplicate, amount: hasDuplicate.amount + 1 }
            : i,
        ),
      );
    } else {
      setCart([...cart, { ...item, amount: 1 }]);
    }
  };

  const removeItem = (item: CartOptions): void => {
    const cartRemove = cart.filter((i: Data) => i.name !== item.name);
    setCart(cartRemove);
  };

  const totalPrice = (): string => {
    const cartMap = cart.map(
      ({ preco, amount }: { preco: string; amount: number }) => {
        const priceClean = Number(preco.replace('R$: ', '').replace(',', '.'));
        return priceClean * amount;
      },
    );
    const calc = cartMap.reduce((a: number, b: number) => a + b);
    return `R$ ${calc.toFixed(2)}`;
  };

  const clearCart = (): void => {
    setCart([]);
  };

  const disableButton = (item: CartOptions): boolean => {
    return item.amount === 1 ? true : false;
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <Title title="Cart" />
      <Header />
      {cart.length === 0 && (
        <EmptyCart>
          <CartContainer>
            <CartTitle>Carrinho</CartTitle>
            <EmptyMessage>Seu carrinho está vazio.</EmptyMessage>
          </CartContainer>
        </EmptyCart>
      )}
      {cart.length > 0 && (
        <CartStyle>
          <CartContainer>
            <CartTitle>Carrinho</CartTitle>
            {cart &&
              cart.map((item: CartOptions, index: number) => {
                return (
                  <CartList key={index}>
                    <CartListItem>
                      Produto: <span>{item.name}</span>
                    </CartListItem>
                    <CartListItem>
                      Preço: <span>{item.preco}</span>
                    </CartListItem>
                    <CartListItem>
                      Quantidade:
                      <button
                        disabled={disableButton(item)}
                        onClick={() => decrement(item)}
                      >
                        -
                      </button>
                      <span className="amount">{item.amount}</span>
                      <button onClick={() => increment(item)}>+</button>
                    </CartListItem>
                    <TrashSvg
                      onClick={() => removeItem(item)}
                      fill="currentColor"
                      width={20}
                      height={20}
                    />
                  </CartList>
                );
              })}
          </CartContainer>
          <CartFinish>
            <FinishTitle>Finalizar</FinishTitle>
            <FinishList>
              <FinishListItem>
                Total: <span>{totalPrice()}</span>
              </FinishListItem>
              <FinishListItem>
                Produtos: <span>{cart.length}</span>
              </FinishListItem>
              <FinishListItem>
                <button onClick={() => clearCart()}>Limpar</button>
              </FinishListItem>
            </FinishList>
          </CartFinish>
        </CartStyle>
      )}

      <Footer />
    </>
  );
};
