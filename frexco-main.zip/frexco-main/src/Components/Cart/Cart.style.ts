import styled from 'styled-components';
import { colors, fontWeight, fontSize } from '../../Styles/Styles';

export const EmptyCart = styled.div`
  min-height: 80vh;
  animation: enter 0.3s;
  @keyframes enter {
    from {
      opacity: 0;
      transform: translate3d(0, -20px, 0);
    }
    to {
      opacity: initial;
      transform: initial;
    }
  }
`;

export const EmptyMessage = styled.p`
  font-weight: ${fontWeight.regular};
  font-size: ${fontSize.md};
`;

export const CartStyle = styled.div`
  min-height: 80vh;
  display: flex;
  align-items: center;
  justify-content: flex-start;
  flex-direction: column;
  animation: enter 0.3s;
  @keyframes enter {
    from {
      opacity: 0;
      transform: translate3d(0, -20px, 0);
    }
    to {
      opacity: initial;
      transform: initial;
    }
  }
`;

export const CartContainer = styled.div`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
`;

export const CartTitle = styled.h1`
  margin: 20px 0;
  color: ${colors.orange};
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.lg};
`;

export const CartList = styled.ul`
  box-shadow: 0 6px 12px rgba(30, 60, 90, 0.2);
  background-color: ${colors.white};
  width: 80%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  border-radius: 8px;
  padding: 20px 50px;
  & + & {
    margin-top: 10px;
  }
  @media only screen and (max-width: 1100px) {
    width: 90%;
    flex-direction: column;
    height: 300px;
  }
`;

export const CartListItem = styled.li`
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.md};
  display: flex;
  align-items: center;
  justify-content: start;
  min-width: 250px;
  span {
    margin-left: 10px;
    color: ${colors.purle1};
    font-weight: ${fontWeight.bold};
    font-size: ${fontSize.md};
    &.amount {
      margin: 0;
    }
  }
  button {
    font-size: ${fontSize.md};
    background-color: #eee;
    border: none;
    width: 25px;
    border-radius: 8px;
    transition: 0.3s;
    margin: 0 10px;
    &:hover {
      background-color: #ccc;
    }
  }
`;

export const CartFinish = styled.div`
  display: flex;
  align-items: center;
  justify-content: center;
  flex-direction: column;
  width: 60%;
  @media only screen and (max-width: 1100px) {
    width: 80%;
  }
`;

export const FinishTitle = styled.h1`
  color: ${colors.orange};
  font-size: ${fontSize.lg};
  font-weight: ${fontWeight.bold};
  margin: 20px 0;
`;

export const FinishList = styled.ul`
  width: 100%;
  display: flex;
  align-items: center;
  justify-content: space-around;
  box-shadow: 0 6px 12px rgba(30, 60, 90, 0.2);
  background-color: ${colors.white};
  padding: 20px 50px;
  border-radius: 8px;
  margin-bottom: 50px;
  @media only screen and (max-width: 1100px) {
    flex-direction: column;
    height: 300px;
  }
`;

export const FinishListItem = styled.li`
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.md};
  display: flex;
  align-items: center;
  justify-content: center;
  span {
    margin-left: 10px;
    color: ${colors.purle1};
    font-weight: ${fontWeight.bold};
    font-size: ${fontSize.md};
  }
  button {
    border: none;
    background-color: ${colors.purle1};
    color: ${colors.white};
    font-weight: ${fontWeight.bold};
    font-size: ${fontSize.md};
    border-radius: 8px;
    padding: 10px 20px;
    transition: 0.3s;
    &:hover {
      transform: scale(1.1);
      background-color: ${colors.purle2};
      cursor: pointer;
    }
  }
`;
