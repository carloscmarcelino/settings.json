export * from './getProduct';
