import axios, { AxiosResponse } from 'axios';
import { API_URL } from '../../../Api';

export const getProduct = (product: string): Promise<AxiosResponse> => {
  return axios.get(API_URL + product);
};
