import { useState, useEffect } from 'react';
import { getProduct } from '../api/getProduct';
import { Data as Product } from '../../../Types/Data';

type Data = {
  product: Product;
};

export const useProduct = (product: any) => {
  const [data, setData] = useState<Data>();

  const getData = async () => {
    const data = await getProduct(product);
    setData(data.data);
  };

  useEffect(() => {
    getData();
  }, []);

  return { data };
};
