import styled from 'styled-components';
import { colors, fontSize, fontWeight, lineHeight } from '../../Styles/Styles';

export const ProductStyle = styled.div`
  min-height: 80vh;
  display: flex;
  align-items: center;
  justify-content: center;
`;

export const ProductBox = styled.div`
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  padding: 10px;
  border-radius: 8px;
  background-color: ${colors.white};
  box-shadow: 0 6px 12px rgba(30, 60, 90, 0.2);
  animation: enter 0.3s;
  @keyframes enter {
    from {
      opacity: 0;
      transform: translate3d(0, -20px, 0);
    }
    to {
      opacity: initial;
      transform: initial;
    }
  }
  @media only screen and (max-width: 1000px) {
    flex-direction: column-reverse;
    margin: 50px 0;
  }
  @media only screen and (max-width: 500px) {
    width: 100%;
  }
`;

export const Image = styled.img`
  width: 450px;
  height: 750px;
  margin-right: 10px;
  border-radius: 8px;
  @media only screen and (max-width: 1000px) {
    margin-right: 0;
  }
  @media only screen and (max-width: 500px) {
    width: 100%;
    margin-right: 0;
    margin-bottom: 50px;
  }
`;

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  align-items: start;
  justify-content: center;
  @media only screen and (max-width: 500px) {
    margin: 50px 0;
  }
`;

export const Title = styled.h1`
  color: ${colors.orange};
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.lg};
  margin-bottom: 10px;
`;

export const Description = styled.p`
  font-weight: ${fontWeight.regular};
  font-size: ${fontSize.md};
  line-height: ${lineHeight.md};
  max-width: 400px;
`;

export const Nutritions = styled.ul`
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  justify-content: center;
  width: 100%;
  margin-top: 10px;
  margin-bottom: 10px;
`;

export const Li = styled.li`
  display: flex;
  justify-content: center;
  align-items: center;
  font-weight: ${fontWeight.regular};
  font-size: ${fontSize.md};
  line-height: ${lineHeight.md};
  &::before {
    content: '';
    display: inline-block;
    margin-right: 10px;
    border-radius: 5px;
    width: 5px;
    height: 5px;
    background-color: #333;
  }
  span {
    font-weight: ${fontWeight.bold};
    color: ${colors.purle1};
    margin-left: 5px;
  }
`;

export const Price = styled.h2`
  color: ${colors.purle1};
  font-size: ${fontSize.lg};
  font-weight: ${fontWeight.bold};
  margin-bottom: 10px;
`;

export const Button = styled.button`
  background-color: ${colors.purle1};
  border: none;
  border-radius: 8px;
  padding: 10px 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: 0.3s;
  &:hover {
    cursor: pointer;
    transform: scale(1.1);
    background-color: ${colors.purle2};
  }
  p {
    color: ${colors.white};
    font-weight: ${fontWeight.bold};
    font-size: ${fontSize.md};
    margin-right: 10px;
  }
`;
