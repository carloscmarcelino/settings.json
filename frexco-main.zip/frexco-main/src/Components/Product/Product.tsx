import { useContext, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { Footer } from '../Footer';
import { Header } from '../Header';
import {
  ProductStyle,
  ProductBox,
  Title,
  Image,
  Button,
  Container,
  Description,
  Price,
  Nutritions,
  Li,
} from './Product.style';
import { useProduct } from './hooks';
import { Title as HeadTitle } from '../Title';
import { Loading } from '../Loading';
import CartSvg from '../../Images/CartSvg';
import { UserContext } from '../../Context/UserStorage';
import { Data } from '../../Types/Data';

export const Product = () => {
  const { product } = useParams();

  const { data } = useProduct(product);

  const { cart, setCart } = useContext(UserContext);

  const addToCart = () => {
    const hasDuplicate = cart.find((i: Data) => i.id === data?.product.id);
    if (hasDuplicate) {
      setCart(
        cart.map((i: Data) => {
          return i.id === data?.product.id
            ? { ...hasDuplicate, amount: hasDuplicate.amount + 1 }
            : i;
        }),
      );
    } else {
      setCart([...cart, { ...data?.product, amount: 1 }]);
    }
  };

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <>
      <HeadTitle title={product} />
      <Header />
      <ProductStyle>
        {!data && <Loading />}
        {data && (
          <ProductBox>
            <Image
              src={data?.product.image.src}
              alt={data?.product.image.alt}
            />
            <Container>
              <Title>{data?.product.name}</Title>
              <Description>
                A banana é uma fruta tropical rica em carboidratos, vitaminas e
                minerais que proporcionam diversos benefícios para a saúde, como
                garantir energia, aumentar a sensação de saciedade e de bem
                estar.
              </Description>
              <Description>
                Essa fruta é muito versátil, podendo ser consumida madura ou
                verde, e cujas propriedades podem variar, principalmente a nível
                digestivo. Essa fruta pode também ser consumida crua ou cozida,
                inteira ou amassada e utilizada na preparação de pratos doces ou
                em saladas.
              </Description>
              <Nutritions>
                <Li>
                  Calorias: <span>{data?.product.nutritions.calories}kcal</span>{' '}
                </Li>
                <Li>
                  Carboidrato:{' '}
                  <span>{data?.product.nutritions.carbohydrates}g</span>{' '}
                </Li>
                <Li>
                  Gordura: <span>{data?.product.nutritions.fat}g</span>{' '}
                </Li>
                <Li>
                  Proteina: <span>{data?.product.nutritions.protein}g</span>{' '}
                </Li>
                <Li>
                  Açucar: <span>{data?.product.nutritions.sugar}g</span>{' '}
                </Li>
              </Nutritions>
              <Price>{data?.product.preco}</Price>
              <Button onClick={addToCart}>
                <p>Adicionar</p>
                <CartSvg fill="currentColor" width={20} height={20} />
              </Button>
            </Container>
          </ProductBox>
        )}
      </ProductStyle>
      <Footer />
    </>
  );
};
