import styled from 'styled-components';
import { colors, fontSize, fontWeight } from '../../Styles/Styles';

export const HeaderStyle = styled.header`
  background-color: ${colors.white};
  box-shadow: 0 2px 4px rgba(30, 60, 90, 0.1);
  width: 100%;
  min-height: 10vh;
`;

export const Container = styled.ul`
  height: 10vh;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-around;
`;

export const Title = styled.h1`
  font-weight: ${fontWeight.bold};
  font-size: ${fontSize.lg};
  color: ${colors.purle1};
  transition: 0.3s;
  position: relative;
  &:hover {
    cursor: pointer;
  }
  &::after {
    content: '';
    position: absolute;
    background-color: ${colors.purle1};
    height: 3px;
    width: 0;
    left: 0;
    bottom: -5px;
    transition: 0.3s;
  }
  &:hover::after {
    width: 100%;
  }
`;

export const Button = styled.h1`
  background-color: ${colors.purle1};
  transition: 0.3s;
  padding: 10px 20px;
  border-radius: 5px;
  color: ${colors.white};
  font-size: ${fontSize.md};
  font-weight: ${fontWeight.bold};
  &:hover {
    cursor: pointer;
    transform: scale(1.1);
    background-color: ${colors.purle2};
  }
  span {
    margin-right: 5px;
    color: ${colors.white};
    font-size: ${fontSize.md};
    font-weight: ${fontWeight.bold};
  }
`;
