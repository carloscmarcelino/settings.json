import { useNavigate } from 'react-router-dom';
import { HeaderStyle, Container, Title, Button } from './Header.style';
import { useContext } from 'react';
import { UserContext } from '../../Context/UserStorage';

export const Header = () => {
  const navigate = useNavigate();

  const { cart } = useContext(UserContext);

  return (
    <HeaderStyle>
      <Container>
        <Title
          onClick={() => {
            navigate('/');
          }}
        >
          Frexco
        </Title>
        <Button
          onClick={() => {
            navigate('/cart');
          }}
        >
          <span>{cart && cart.length > 0 && cart.length}</span>
          Carrinho
        </Button>
      </Container>
    </HeaderStyle>
  );
};
