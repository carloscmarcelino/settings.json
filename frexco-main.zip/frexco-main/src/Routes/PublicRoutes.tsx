import { Cart, Dashboard } from '../Components';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { Product, PageNotFound } from '../Components';

const PublicRoutes = () => {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/Product/:product" element={<Product />} />
        <Route path="cart" element={<Cart />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </BrowserRouter>
  );
};

export default PublicRoutes;
